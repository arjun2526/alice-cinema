package com.alice.cinema

enum class ViewingMode(val label: String) {
    CINEMA_2D("Cinema 2D"),
    STEREO_SBS("3D · Side by side"),
    STEREO_TAB("3D · Top and bottom")
}
