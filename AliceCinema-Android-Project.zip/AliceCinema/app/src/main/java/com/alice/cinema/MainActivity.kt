package com.alice.cinema

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF09090D)
private val Panel = Color(0xFF171720)
private val Purple = Color(0xFFAC8BFF)
private val MainText = Color(0xFFF4F0FF)
private val Muted = Color(0xFFAAA6B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 13)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 13)
        setContent { AliceTheme { AliceCinemaApp() } }
    }
}

@Composable
private fun AliceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Night,
            surface = Panel,
            onBackground = MainText,
            onSurface = MainText
        ),
        content = content
    )
}

@Composable
fun AliceCinemaApp() {
    var mode by remember { mutableStateOf(ViewingMode.CINEMA_2D) }
    var connected by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("English") }
    var aiEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Night)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("A L I C E", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Cinema", color = MainText, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("Your personal cinema companion", color = Muted, fontSize = 14.sp)
            }
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(Brush.linearGradient(listOf(Purple, Color(0xFF5B43A4))), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) { Text("A", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black) }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF29213D), Color(0xFF15151E))), RoundedCornerShape(24.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("YOUR PRIVATE SCREEN", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("A bigger world.\nA lighter frame.", color = MainText, fontSize = 26.sp, lineHeight = 31.sp, fontWeight = FontWeight.SemiBold)
            Text("ALICE Cinema V1 · Software preview", color = Muted, fontSize = 12.sp)
            Button(onClick = { playing = !playing }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text(if (playing) "Ⅱ  Pause demo" else "▶  Play demo")
            }
            Text(if (playing) "Demo playback active — no video is playing yet." else "Ready when you are", color = Muted, fontSize = 12.sp)
        }

        SectionCard(title = "VIEWING MODE", subtitle = "Choose a compatible source format") {
            ViewingMode.entries.forEach { option ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = mode == option, onClick = { mode = option })
                    Column(Modifier.padding(start = 6.dp)) {
                        Text(option.label, color = MainText, fontWeight = FontWeight.Medium)
                        Text(
                            when (option) {
                                ViewingMode.CINEMA_2D -> "Standard video · same image to both eyes"
                                ViewingMode.STEREO_SBS -> "Stereoscopic source arranged left/right"
                                ViewingMode.STEREO_TAB -> "Stereoscopic source arranged top/bottom"
                            }, color = Muted, fontSize = 11.sp
                        )
                    }
                }
            }
            Text("3D needs compatible stereo video, a stereo renderer and binocular optics. This selector is a prototype only.", color = Muted, fontSize = 12.sp)
        }

        SectionCard(title = "GLASSES CONNECTION", subtitle = "Phone connection · demo state") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(if (connected) Color(0xFF64D6A0) else Color.Gray, RoundedCornerShape(50)))
                Spacer(Modifier.width(9.dp))
                Text(if (connected) "Demo connected" else "No glasses connected", color = MainText)
            }
            Button(onClick = { connected = !connected }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text(if (connected) "Disconnect demo" else "Simulate connection")
            }
        }

        SectionCard(title = "ALICE ASSISTANT", subtitle = "Hindi + English · integration planned") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Voice assistant", color = MainText)
                    Text(if (aiEnabled) "Demo enabled — no AI service connected" else "Not connected", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = aiEnabled, onCheckedChange = { aiEnabled = it })
            }
            OutlinedButton(onClick = { language = if (language == "English") "Hindi" else "English" }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("Language: $language")
            }
        }

        SectionCard(title = "QUICK CONTROLS", subtitle = "Prototype buttons") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { playing = !playing }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(if (playing) "Pause" else "Play") }
                OutlinedButton(onClick = { connected = !connected }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Bluetooth demo") }
            }
        }
        Text("ALICE V1  •  PROTOTYPE ONLY  •  NO HARDWARE CONNECTED", color = Color(0xFF777383), fontSize = 10.sp, letterSpacing = 0.7.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = {
            Text(title, color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
            content()
        }
    )
}
