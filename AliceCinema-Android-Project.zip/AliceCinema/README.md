# ALICE Cinema V1 — Android project

A Kotlin + Jetpack Compose UI prototype for the ALICE AI glasses companion app.

## Important
This is a software prototype. The Play, glasses connection, AI, and language controls are demo state only. No physical glasses, camera, Gemini service, or true 3D renderer is connected yet. The 3D options identify SBS/TAB formats but do not split or render stereoscopic video.

## Build an APK (Windows + Android Studio)
1. Install Android Studio and Android SDK Platform 35.
2. Extract this folder.
3. Open the `AliceCinema` folder in Android Studio.
4. Allow Gradle sync and install any requested SDK components.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Project
- Kotlin
- Jetpack Compose
- Android SDK 35, minimum Android 8.0 (API 26)
- Media3 dependencies are included for the next video-player development stage.

## Next engineering stages
1. Implement a local file picker and real Media3 playback.
2. Add stereo SBS/TAB decoding and a verified binocular display output path.
3. Implement BLE controls against actual frame firmware.
4. Add optional AI services and Android notification permissions.
